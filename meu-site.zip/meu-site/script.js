document.addEventListener('DOMContentLoaded', function() {
    // Proteção básica contra clickjacking
    if (self === top) {
        document.documentElement.style.visibility = 'visible';
    } else {
        top.location = self.location;
    }

    // Verificação de segurança
    const joinButton = document.getElementById('joinButton');
    
    joinButton.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Confirmação antes de redirecionar
        if (confirm('Você está sendo redirecionado para o Discord. Deseja continuar?')) {
            // Análise básica de segurança
            const isSecure = window.location.protocol === 'https:';
            
            if (isSecure) {
                window.location.href = this.href;
            } else {
                alert('Por segurança, use uma conexão HTTPS para acessar este link.');
            }
        }
    });

    // Proteção contra bots (simplificada)
    console.log('Proteção ativada: Este site possui mecanismos anti-spam');
});